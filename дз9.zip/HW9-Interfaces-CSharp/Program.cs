using Task21;
using Task22;
using Task23;

Console.WriteLine("=== Задание 2.1. Бой рыцаря и мага ===");
CombatDemo.Run();

Console.WriteLine();
Console.WriteLine("=== Задание 2.2. Игровые предметы ===");
ItemsDemo.Run();

Console.WriteLine();
Console.WriteLine("=== Задание 2.3. Система расчёта урона ===");
DamageDemo.Run();
