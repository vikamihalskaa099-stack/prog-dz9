namespace Task23;

public interface IDamageCalculator
{
    int CalculateDamage(int baseDamage, int targetArmor);
}

public class PhysicalDamageCalculator : IDamageCalculator
{
    public int CalculateDamage(int baseDamage, int targetArmor)
    {
        return Math.Max(1, baseDamage - targetArmor / 2);
    }
}

public class MagicDamageCalculator : IDamageCalculator
{
    public int CalculateDamage(int baseDamage, int targetArmor)
    {
        int damage = baseDamage - targetArmor / 4;

        if (targetArmor == 0)
        {
            damage *= 2;
        }

        return Math.Max(1, damage);
    }
}

public class FireDamageCalculator : IDamageCalculator
{
    public int CalculateDamage(int baseDamage, int targetArmor)
    {
        int damage = baseDamage - targetArmor / 10;

        if (baseDamage > 50)
        {
            damage += 10;
        }

        return Math.Max(1, damage);
    }
}

public class Unit
{
    public string Name { get; }
    public int HP { get; set; }
    public int Armor { get; }

    public Unit(string name, int hp, int armor)
    {
        Name = name;
        HP = Math.Max(0, hp);
        Armor = Math.Max(0, armor);
    }
}

public class DamageSystem
{
    private readonly IDamageCalculator _calculator;

    public DamageSystem(IDamageCalculator calculator)
    {
        _calculator = calculator;
    }

    public void ApplyDamage(Unit target, int baseDamage)
    {
        int damage = _calculator.CalculateDamage(baseDamage, target.Armor);
        target.HP = Math.Max(0, target.HP - damage);

        Console.WriteLine(
            $"Юнит {target.Name} получил {damage} урона. Осталось HP: {target.HP}");
    }
}

public static class DamageDemo
{
    public static void Run()
    {
        var physicalTarget = new Unit("Голем", 150, 20);
        var magicTarget = new Unit("Голем", 150, 20);
        var fireTarget = new Unit("Голем", 150, 20);

        var physicalSystem = new DamageSystem(new PhysicalDamageCalculator());
        var magicSystem = new DamageSystem(new MagicDamageCalculator());
        var fireSystem = new DamageSystem(new FireDamageCalculator());

        physicalSystem.ApplyDamage(physicalTarget, 60);
        magicSystem.ApplyDamage(magicTarget, 60);
        fireSystem.ApplyDamage(fireTarget, 60);

        // Чтобы добавить ледяной урон, достаточно создать новый класс,
        // реализующий IDamageCalculator, и передать его в DamageSystem.
        // Сам класс DamageSystem при этом менять не требуется.
    }
}
